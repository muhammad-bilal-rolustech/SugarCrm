<?php
// created: 2017-08-28 14:15:19
$dictionary["bus_BusManagment"]["fields"]["bus_busmanagment_bus_passenger"] = array (
  'name' => 'bus_busmanagment_bus_passenger',
  'type' => 'link',
  'relationship' => 'bus_busmanagment_bus_passenger',
  'source' => 'non-db',
  'module' => 'bus_Passenger',
  'bean_name' => 'bus_Passenger',
  'vname' => 'LBL_BUS_BUSMANAGMENT_BUS_PASSENGER_FROM_BUS_BUSMANAGMENT_TITLE',
  'id_name' => 'bus_busmanagment_bus_passengerbus_busmanagment_ida',
  'link-type' => 'many',
  'side' => 'left',
);
