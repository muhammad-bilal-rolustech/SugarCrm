<?php
// created: 2017-08-28 14:15:19
$viewdefs['bus_BusManagment']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BUS_BUSMANAGMENT_BUS_PASSENGER_FROM_BUS_PASSENGER_TITLE',
  'context' => 
  array (
    'link' => 'bus_busmanagment_bus_passenger',
  ),
);