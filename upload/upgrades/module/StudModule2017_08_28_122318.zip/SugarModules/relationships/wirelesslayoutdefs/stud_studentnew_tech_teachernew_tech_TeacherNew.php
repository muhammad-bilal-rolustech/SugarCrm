<?php
 // created: 2017-08-28 12:23:18
$layout_defs["tech_TeacherNew"]["subpanel_setup"]['stud_studentnew_tech_teachernew'] = array (
  'order' => 100,
  'module' => 'stud_StudentNew',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_STUD_STUDENTNEW_TECH_TEACHERNEW_FROM_STUD_STUDENTNEW_TITLE',
  'get_subpanel_data' => 'stud_studentnew_tech_teachernew',
);
