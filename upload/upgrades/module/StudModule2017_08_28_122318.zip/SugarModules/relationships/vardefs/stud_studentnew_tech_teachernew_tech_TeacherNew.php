<?php
// created: 2017-08-28 12:23:18
$dictionary["tech_TeacherNew"]["fields"]["stud_studentnew_tech_teachernew"] = array (
  'name' => 'stud_studentnew_tech_teachernew',
  'type' => 'link',
  'relationship' => 'stud_studentnew_tech_teachernew',
  'source' => 'non-db',
  'module' => 'stud_StudentNew',
  'bean_name' => 'stud_StudentNew',
  'vname' => 'LBL_STUD_STUDENTNEW_TECH_TEACHERNEW_FROM_TECH_TEACHERNEW_TITLE',
  'id_name' => 'stud_studentnew_tech_teachernewtech_teachernew_ida',
  'link-type' => 'many',
  'side' => 'left',
);
