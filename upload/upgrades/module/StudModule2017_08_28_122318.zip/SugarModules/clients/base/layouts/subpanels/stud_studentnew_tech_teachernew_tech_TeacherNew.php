<?php
// created: 2017-08-28 12:23:18
$viewdefs['tech_TeacherNew']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_STUD_STUDENTNEW_TECH_TEACHERNEW_FROM_STUD_STUDENTNEW_TITLE',
  'context' => 
  array (
    'link' => 'stud_studentnew_tech_teachernew',
  ),
);